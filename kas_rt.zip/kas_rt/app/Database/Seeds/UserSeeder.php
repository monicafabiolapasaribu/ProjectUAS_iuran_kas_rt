<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $model = model('UserModel');
		$model->insert([
            'username' => 'Monica_Fabiola',
			'useremail' => 'monicafbl.2309@gmail.com',
			'userpassword' => password_hash('MncfP0109', PASSWORD_DEFAULT),
        ]);
    }
}
