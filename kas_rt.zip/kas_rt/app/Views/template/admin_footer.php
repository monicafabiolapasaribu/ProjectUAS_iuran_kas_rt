<footer>
        <p>&copy; 2022  Monica Fabiola Pasaribu - 312010083 - TI.20.D.1  Universitas Pelita Bangsa</p>
    </footer>
    </div>
</body>
</html>
